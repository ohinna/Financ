# Finances

App pessoal de controle financeiro: bolsos/cartões com limite, categorias personalizáveis,
gráfico da semana, temas de cor e tudo salvo automaticamente no navegador.

## Rodando localmente

Pré-requisitos: [Node.js](https://nodejs.org) 18 ou mais recente.

```bash
npm install
npm run dev
```

Abre em `http://localhost:5173`.

## Build de produção

```bash
npm run build
npm run preview
```

Os arquivos finais ficam em `dist/`, prontos pra hospedar em qualquer serviço
de site estático (Vercel, Netlify, GitHub Pages, etc).

## Onde os dados ficam salvos

Por enquanto os dados (bolsos, lançamentos, categorias, tema) ficam salvos no
`localStorage` do navegador de quem está usando — ou seja, os dados são por
navegador/dispositivo, não sincronizam entre celular e computador ainda.

Se no futuro vocês quiserem que duas pessoas vejam os mesmos dados em
aparelhos diferentes (por exemplo, sincronizar entre o celular dela e o do
namorado), o próximo passo natural é trocar essa camada de armazenamento por
um banco de dados na nuvem, como o Firebase, com login por e-mail/senha ou
Google. A lógica de bolsos, categorias e limites continua igual — só muda de
onde os dados são lidos e salvos.

## Como subir pro GitHub

Se ainda não tem um repositório criado no GitHub:

1. Cria um repositório novo em [github.com/new](https://github.com/new)
   (pode deixar vazio, sem README/gitignore, já que o projeto já tem os seus).
2. No terminal, dentro desta pasta:

```bash
git remote add origin https://github.com/SEU-USUARIO/NOME-DO-REPOSITORIO.git
git branch -M main
git push -u origin main
```

Troque `SEU-USUARIO` e `NOME-DO-REPOSITORIO` pelos dados do seu repositório.
Na primeira vez, o GitHub vai pedir suas credenciais (usuário e um
[token de acesso pessoal](https://github.com/settings/tokens), já que senha
comum não funciona mais para isso).
