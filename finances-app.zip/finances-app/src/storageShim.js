// Polyfill for the window.storage API (get/set/delete/list) using the
// browser's localStorage, so the app works outside of the Claude artifact
// environment without changing any of the storage calls in App.jsx.
const PREFIX = "finances-app:";

function readAll() {
  try {
    const raw = localStorage.getItem(PREFIX + "__all__");
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    return {};
  }
}

function writeAll(data) {
  localStorage.setItem(PREFIX + "__all__", JSON.stringify(data));
}

if (typeof window !== "undefined" && !window.storage) {
  window.storage = {
    async get(key) {
      const all = readAll();
      if (!(key in all)) return null;
      return { key, value: all[key], shared: false };
    },
    async set(key, value) {
      const all = readAll();
      all[key] = value;
      writeAll(all);
      return { key, value, shared: false };
    },
    async delete(key) {
      const all = readAll();
      const existed = key in all;
      delete all[key];
      writeAll(all);
      return { key, deleted: existed, shared: false };
    },
    async list(prefix = "") {
      const all = readAll();
      const keys = Object.keys(all).filter((k) => k.startsWith(prefix));
      return { keys, prefix, shared: false };
    },
  };
}
